class Product:
    id: str
    name: str