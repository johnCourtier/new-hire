import array
from product import Product
from address import Address

class ProductRepository:
    def getProducts(self, address: Address) -> array.array[Product]:
        pass;