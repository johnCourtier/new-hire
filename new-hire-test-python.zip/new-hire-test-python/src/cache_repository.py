class CacheRepository:
    def getKey(self, key: str):
        pass