class Address:
    id: str
    fullAddressName: str
    city: str
    street: str
    streetNumber: str