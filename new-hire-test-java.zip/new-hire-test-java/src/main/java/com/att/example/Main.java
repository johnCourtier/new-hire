package com.att.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("This is just an example, ProductQualifier class usage is not implemented.");
    }
}