package com.att.example;

import java.util.ArrayList;
import java.util.List;

public class ProductQualifier {
    private List<Product> availableProducts = new ArrayList<>();
    private Address address;

    public ProductQualifier(Address address) {
        this.address = address;
    }

    public List<Product> getAvailableProducts() {
        ProductRepository primarySource = new ProductRepository();
        List<Product>primaryProducts = primarySource.getProducts(this.address);
        for (Product element : primaryProducts) {
            boolean add = true;
            for (Product availableProduct : this.availableProducts) {
                if (availableProduct.getId().equals(element.getId())) {
                    add = false;
                }
            }
            if (add) {
                this.availableProducts.add(element);
            } else {
                System.out.println("Product already exists.");
            }
        }

        CacheRepository cacheSource = new CacheRepository();
        List<Product> cachedProducts = cacheSource.getKey(this.address.getFullAddressName());
        for (Product element : cachedProducts) {
            boolean add = true;
            for (Product availableProduct : this.availableProducts) {
                if (availableProduct.getId().equals(element.getId())) {
                    add = false;
                }
            }
            if (add) {
                this.availableProducts.add(element);
            } else {
                System.out.println("Product already exists.");
            }
        }

        int cacheEfficiency = cachedProducts.size() / (cachedProducts.size() + primaryProducts.size());
        System.out.println("Cache efficiency: " + cacheEfficiency);

        return this.availableProducts;
    }

    public char getAddressCategory() {
        if (this.availableProducts.size() > 2) {
            return 'A';
        } else if (this.availableProducts.size() > 4) {
            return 'B';
        } else {
            return 'C';
        }
    }
}
