package com.att.example;

import java.util.List;

public class ProductRepository {
    public List<Product> getProducts(Address address) {
        return null;
    }
}
