declare module 'CacheRepository' {
    export class CacheRepository {
        getKey(key: string)
    }
}