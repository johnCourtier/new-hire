interface Product {
    id: string;
    name: string;
}