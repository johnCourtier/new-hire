import { CacheRepository } from "CacheRepository";
import { ProductRepository } from "ProductRepository";

class ProductQualifier {

    private availableProducts!: Product[];

    public constructor(private address: Address) {

    }

    public getAvailableProducts(): Product[] {
        const primarySource = new ProductRepository();
        const primaryProducts = primarySource.getProducts(this.address);
        primaryProducts.forEach((element: Product) => {
            let add = true;
            this.availableProducts.forEach((availableProduct: Product) => {
                if (availableProduct.id == element.id) {
                    add = false;
                }
            });
            if (add) {
                this.availableProducts.push(element);
            } else {
                console.log('Product already exists.');
            }
        });

        const cacheSource = new CacheRepository();
        const cachedProducts = cacheSource.getKey(this.address.fullAddressName);
        cachedProducts.forEach((element: Product) => {
            let add = true;
            this.availableProducts.forEach((availableProduct: Product) => {
                if (availableProduct.id == element.id) {
                    add = false;
                }
            });
            if (add) {
                this.availableProducts.push(element);
            } else {
                console.log('Product already exists.');
            }
        });

        const cacheEfficiency = cachedProducts.length / (cachedProducts.length + primaryProducts.length);
        console.log('Cache efficiency: ' + cacheEfficiency);

        return this.availableProducts;
    }

    public getAddressCategory(): string
    {
        if (this.availableProducts.length > 2) {
            return 'A';
        } else if (this.availableProducts.length > 4) {
            return 'B';
        } else {
            return 'C';
        }
    }
}