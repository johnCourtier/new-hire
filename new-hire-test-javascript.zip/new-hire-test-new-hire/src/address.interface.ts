interface Address {
    id: string;
    fullAddressName: string;
    city: string
    street: string;
    streetNumber: string;
}