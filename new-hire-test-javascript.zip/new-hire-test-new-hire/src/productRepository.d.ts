declare module 'ProductRepository' {
    export class ProductRepository {
        getProducts(address: Address): Product[];
    }
}